# Signage Player – Native Android-App

Native Kotlin-Android-App für dein selbst gehostetes Signage-CMS. Zeigt Kopplungscode beim ersten Start, spielt Playlists ab, überlebt Neustarts.

## Features

- **Pairing-Flow**: erste Konfiguration nur Server-URL, danach nur Code eingeben im Admin
- **ExoPlayer**: hardware-beschleunigte Video-Wiedergabe (Media3)
- **Glide**: effizientes Bild-Handling mit Cache
- **Auto-Start**: startet automatisch beim Booten des Geräts
- **Wake-Lock**: Bildschirm bleibt permanent an
- **Kiosk-Modus**: Zurück-Button ist deaktiviert, Home-Button versucht Rückkehr zur App
- **Beide Ausrichtungen**: unterstützt Hoch- und Querformat automatisch
- **Setup-Zugang**: 5× auf Server-URL tippen im Pairing-Screen, oder 7× auf den Player tippen in 3 Sekunden

## Wie du zur APK kommst (in 5 Schritten, ~30 Min)

### Schritt 1: GitHub-Account erstellen (falls noch nicht vorhanden)

Auf [github.com](https://github.com) → **Sign up** → Konto erstellen (kostenlos).

### Schritt 2: Neues Repository anlegen

1. Nach dem Login oben rechts auf das **+** → **New repository**
2. Repository-Name: `signage-player-android` (oder wie du magst)
3. Sichtbarkeit: **Private** (empfohlen, damit dein Code nicht öffentlich ist)
4. Wichtig: NICHT ankreuzen "Add a README file", "Add .gitignore", "Add license"
5. Klick auf **Create repository**

### Schritt 3: Projekt zu GitHub hochladen

Zwei Wege:

**Option A: GitHub Desktop (einfacher, empfohlen für den Anfang)**

1. [GitHub Desktop herunterladen](https://desktop.github.com) und installieren
2. In GitHub Desktop mit deinem GitHub-Account einloggen
3. **File** → **Add local repository** → den entpackten `signage-player-android`-Ordner auswählen
4. GitHub Desktop meldet vermutlich "This directory does not appear to be a Git repository" – auf **create a repository** klicken
5. Repository-Namen setzen (gleicher wie in Schritt 2)
6. **Publish repository** oben rechts
7. Häkchen "Keep this code private" setzen
8. **Publish**

Nach 30 Sekunden ist dein Code auf GitHub.

**Option B: Web-Upload (schnell für einmalig)**

1. Im leeren Repository auf GitHub auf "**uploading an existing file**" klicken
2. Alle Ordner und Dateien aus `signage-player-android` per Drag & Drop reinziehen
3. Ganz unten Commit message: "Initial commit"
4. **Commit changes**

### Schritt 4: APK-Build starten

Sobald der Code im Repository ist, läuft der Build automatisch los:

1. Im Repository oben auf den Tab **Actions** klicken
2. Du solltest einen Eintrag "Build APK" sehen mit einem gelben Punkt (läuft) oder grünen Häkchen (fertig)
3. Der erste Build dauert ~7 Minuten (Android SDK wird geladen)

Falls kein Build läuft: **Actions** → **Build APK** (links in der Liste) → **Run workflow** → **Run workflow**.

### Schritt 5: APK herunterladen

1. Wenn der Build grün ist, klick den Build-Eintrag an
2. Ganz unten unter **Artifacts** siehst du **SignagePlayer-APK**
3. Klick drauf → wird als ZIP heruntergeladen
4. ZIP entpacken → drin ist `SignagePlayer.apk`

Diese APK kannst du jetzt auf beliebig viele Android-Geräte kopieren.

## APK auf Android-Gerät installieren

### Auf einem Tablet

1. **Installation aus unbekannten Quellen erlauben**:
   Einstellungen → Sicherheit → "Unbekannte Quellen" aktivieren
   (oder: bei Android 8+ direkt beim Öffnen der APK erlauben)

2. **APK aufs Gerät bringen** – wähle einen Weg:
   - USB-Kabel + Dateimanager
   - Cloud (Google Drive, Dropbox) → APK dort ablegen, auf dem Tablet öffnen
   - E-Mail an sich selbst schicken, auf dem Tablet öffnen
   - Über Fully Kiosk / normalen Browser: die APK auf deinen CMS-Server legen und direkt herunterladen

3. **APK öffnen** → Installation bestätigen

### Erste Einrichtung nach Installation

1. **App öffnen** → "Server-Konfiguration" erscheint
2. **Server-URL eingeben**: z.B. `http://192.168.1.213:3000` (deine CMS-URL)
3. **Speichern**
4. Bildschirm zeigt jetzt riesengroß einen Kopplungscode, z.B. `KMP-T34`
5. Im **CMS-Admin** (am PC/Handy) auf **Bildschirme** → **Bildschirm koppeln** → Code eingeben, Name vergeben, Playlist wählen → **Koppeln**
6. Nach ~3 Sekunden startet die App den Player und zeigt deine Inhalte

### Rücksetzen / Neu koppeln

Wenn du den Bildschirm einem anderen Kunden zuweisen willst oder aus anderen Gründen entkoppeln:

- **Im Pairing-Screen**: 5× schnell auf die Server-URL (unten links) tippen → Setup öffnet sich
- **Im Player**: 7× schnell auf den Bildschirm tippen (innerhalb 3 Sekunden) → Token wird gelöscht, neuer Pairing-Code wird angezeigt

## Wenn du Änderungen machst

Sobald du Code in Git änderst und pushst, baut GitHub automatisch eine neue APK. Der Ablauf:

1. Änderungen im Code machen
2. In GitHub Desktop: **Commit** eingeben → **Commit to main** → **Push origin**
3. Warten bis Build durchgelaufen ist (~5 Min)
4. Neue APK herunterladen
5. Auf allen Tablets installieren (überschreibt die alte, Daten bleiben erhalten)

**Auto-Update-Idee für später**: In der App könnte man eine Update-Prüfung einbauen, die vom Server eine `latest.apk` herunterlädt und installiert. Aktuell nicht implementiert, könnte aber nachgerüstet werden.

## Kiosk-Modus perfektionieren

Die App fängt schon den Zurück-Button ab. Für einen echten Kiosk-Betrieb (verhindert dass jemand die App verlässt) empfehle ich zusätzlich:

### Android 11+: Pin-Modus / App-Pinning

1. Einstellungen → Sicherheit → **Pin-Modus** / **App-Pinning** aktivieren
2. In der App-Übersicht (Übersichts-Taste) auf das App-Icon → **Anpinnen**

Damit kann die App nur mit einer speziellen Tastenkombination verlassen werden.

### Ältere Android-Versionen

Fully Kiosk installieren und als Launcher setzen, dann darin die Signage-App starten lassen. Alternativ ein Custom-Launcher wie Kioware.

## Kostenüberlegung

- APK selbst: kostenlos
- GitHub: kostenlos für Private Repos (2000 Actions-Minuten/Monat gratis, ~400 Builds möglich)
- Kein Fully-Kiosk-Kauf mehr nötig
- Einmalige Setup-Zeit: 30-60 Minuten

Verglichen mit PWA + Fully Kiosk (35 € pro Kunde bei 5 Bildschirmen): amortisiert sich nach dem ersten Kunden.

## Struktur des Projekts

```
signage-player-android/
├── app/
│   ├── build.gradle.kts           # App-Modul mit Dependencies
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/signage/player/
│   │   │   ├── SignageApp.kt        # Application-Klasse
│   │   │   ├── MainActivity.kt      # Router
│   │   │   ├── SetupActivity.kt     # Server-URL eingeben
│   │   │   ├── PairingActivity.kt   # Pairing-Code anzeigen
│   │   │   ├── PlayerActivity.kt    # Der eigentliche Player
│   │   │   ├── ApiClient.kt         # API-Aufrufe
│   │   │   ├── Models.kt            # Daten-Klassen
│   │   │   ├── Prefs.kt             # SharedPreferences
│   │   │   └── BootReceiver.kt      # Auto-Start
│   │   └── res/                     # Layouts, Strings, Farben
├── build.gradle.kts                # Projekt-Level
├── settings.gradle.kts
├── gradle.properties
└── .github/workflows/build.yml     # Automatischer APK-Build
```

## Wenn was schief geht

**Build schlägt fehl:**
- Öffne den fehlgeschlagenen Build-Log unter Actions und lies die Fehlermeldung
- Häufigste Ursache: Tippfehler nach Änderungen. Vergleich mit einer bekannt funktionierenden Version

**APK installiert, aber App startet nicht:**
- Prüf ob dein Gerät Android 5.0 oder neuer hat (minSdk = 21)
- Bei sehr alten Fire TV Sticks: die brauchen manchmal eine spezielle Signatur

**Pairing-Code erscheint, aber Kopplung klappt nicht:**
- Prüf im CMS ob dein Server unter der eingegebenen URL erreichbar ist
- Firewall auf dem CMS-Server: Port 3000 muss von den Tablets erreichbar sein
- HTTPS wäre besser, aber HTTP funktioniert (haben wir mit `usesCleartextTraffic="true"` im Manifest erlaubt)

**Videos hängen oder ruckeln:**
- Codec-Problem – nimm H.264 in MP4 (das ist auf allen Geräten HW-beschleunigt)
- Bitrate reduzieren (für 1080p signage reichen 5 Mbps)

## Was jetzt noch nicht drin ist

- **Offline-Cache**: Videos werden jetzt bei jedem Zeigen neu geladen. Für Bilder nutzt Glide einen automatischen Cache
- **Auto-Update**: manuelle APK-Installation bei jedem Update
- **Screensaver-Verhinderung auf tieferer Ebene**: das WakeLock hilft, aber bei manchen Herstellern (Samsung) braucht es zusätzliche Einstellungen
- **Analytics**: kein Reporting an den Server über tatsächliches Abspielen

Diese Features lassen sich später nachrüsten.
