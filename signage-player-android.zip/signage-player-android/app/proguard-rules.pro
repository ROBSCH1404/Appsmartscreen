# Keep this file empty - ProGuard is disabled for release builds
