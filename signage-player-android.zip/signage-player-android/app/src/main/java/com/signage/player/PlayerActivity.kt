package com.signage.player

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.bumptech.glide.Glide
import com.signage.player.databinding.ActivityPlayerBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PlayerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPlayerBinding
    private var exoPlayer: ExoPlayer? = null

    private var config: PlayerConfig? = null
    private var currentIndex = 0
    private var lastHash = ""

    private var pollJob: Job? = null
    private var itemJob: Job? = null

    private var settingsTapCount = 0
    private var lastTapTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fullscreen + Bildschirm anlassen
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        exoPlayer = ExoPlayer.Builder(this).build().apply {
            volume = 0f // Signage ist immer stumm
            binding.playerView.player = this
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) advance()
                }
            })
        }

        binding.status.text = getString(R.string.player_connecting)

        // 7-Fach-Tap auf den Bildschirm binnen 3 Sekunden → Setup öffnen
        binding.root.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastTapTime > 3_000) settingsTapCount = 0
            lastTapTime = now
            settingsTapCount++
            if (settingsTapCount >= 7) {
                Prefs.reset() // Token zurücksetzen, Server-URL bleibt
                startActivity(Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                })
                finish()
            }
        }

        startPolling()
    }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = lifecycleScope.launch {
            while (true) {
                fetchAndMaybeRestart()
                val interval = (config?.pollIntervalSec ?: 30).toLong()
                delay(interval * 1000)
            }
        }
    }

    private suspend fun fetchAndMaybeRestart() {
        when (val result = ApiClient.fetchPlayerConfig()) {
            is ApiClient.Result.Success -> {
                val newConfig = result.data
                val newHash = newConfig.playlistHash()
                val changed = newHash != lastHash
                lastHash = newHash
                config = newConfig

                if (changed) {
                    currentIndex = 0
                    itemJob?.cancel()
                    playCurrent()
                }
                binding.status.visibility = if (newConfig.items.isEmpty()) View.VISIBLE else View.GONE
                if (newConfig.items.isEmpty()) {
                    binding.status.text = getString(R.string.player_no_playlist)
                }
            }
            is ApiClient.Result.Error -> {
                if (result.code == 404) {
                    // Bildschirm wurde im Admin gelöscht → neu koppeln
                    Prefs.reset()
                    startActivity(Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    })
                    finish()
                    return
                }
                binding.status.visibility = View.VISIBLE
                binding.status.text = getString(R.string.player_connection_error, result.message)
            }
        }
    }

    private fun playCurrent() {
        val cfg = config ?: return
        if (cfg.items.isEmpty()) return
        if (currentIndex >= cfg.items.size) currentIndex = 0
        val item = cfg.items[currentIndex]

        if (item.isImage) {
            binding.playerView.visibility = View.GONE
            binding.imageView.visibility = View.VISIBLE
            Glide.with(this)
                .load(ApiClient.mediaUrl(item.url))
                .into(binding.imageView)
            binding.status.visibility = View.GONE
            scheduleAdvance(item.durationSec.toLong())
        } else if (item.isVideo) {
            binding.imageView.visibility = View.GONE
            binding.playerView.visibility = View.VISIBLE
            exoPlayer?.apply {
                setMediaItem(MediaItem.fromUri(ApiClient.mediaUrl(item.url)))
                prepare()
                play()
            }
            binding.status.visibility = View.GONE
            // Hard-Fallback: falls Video hängt, nach doppelter Dauer weiter
            scheduleAdvance(item.durationSec.toLong() * 2 + 5)
        } else {
            advance()
        }
    }

    private fun scheduleAdvance(seconds: Long) {
        itemJob?.cancel()
        itemJob = lifecycleScope.launch {
            delay(seconds * 1000)
            advance()
        }
    }

    private fun advance() {
        itemJob?.cancel()
        currentIndex++
        playCurrent()
    }

    override fun onResume() {
        super.onResume()
        hideSystemUi()
    }

    // Home-Button abfangen (Kiosk-Modus)
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true // Zurück-Button ignorieren
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        pollJob?.cancel()
        itemJob?.cancel()
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }
}
