package com.signage.player

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.signage.player.databinding.ActivityPairingBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PairingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPairingBinding
    private var pollJob: Job? = null
    private var currentCode: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPairingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Bildschirm anlassen
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        binding.deviceId.text = getString(R.string.device_id_label, Prefs.deviceId)
        binding.serverUrl.text = Prefs.serverUrl ?: ""

        // Fünfmal auf Server-URL tippen → Setup öffnen (versteckte "Reset"-Option)
        var taps = 0
        binding.serverUrl.setOnClickListener {
            taps++
            if (taps >= 5) {
                startActivity(Intent(this, SetupActivity::class.java))
                finish()
            }
        }

        requestCode()
    }

    private fun requestCode() {
        binding.code.text = "……"
        binding.status.text = getString(R.string.pairing_requesting_code)
        pollJob?.cancel()
        pollJob = lifecycleScope.launch {
            when (val result = ApiClient.requestPairingCode()) {
                is ApiClient.Result.Success -> {
                    currentCode = result.data
                    binding.code.text = formatCode(result.data)
                    binding.status.text = getString(R.string.pairing_waiting)
                    pollStatus()
                }
                is ApiClient.Result.Error -> {
                    binding.status.text = getString(R.string.pairing_error_retry, result.message)
                    delay(10_000)
                    requestCode()
                }
            }
        }
    }

    private suspend fun pollStatus() {
        val code = currentCode ?: return
        while (true) {
            delay(3_000)
            when (val result = ApiClient.checkPairingStatus(code)) {
                is ApiClient.Result.Success -> {
                    when (val status = result.data) {
                        is PairingStatus.Paired -> {
                            Prefs.token = status.token
                            binding.status.text = getString(R.string.pairing_success)
                            delay(1_000)
                            startActivity(Intent(this@PairingActivity, PlayerActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            })
                            finish()
                            return
                        }
                        is PairingStatus.Expired -> {
                            requestCode()
                            return
                        }
                        is PairingStatus.Pending -> { /* weiter warten */ }
                    }
                }
                is ApiClient.Result.Error -> {
                    // Bei Netzwerkfehler länger warten
                    delay(5_000)
                }
            }
        }
    }

    private fun formatCode(code: String): String {
        // KMPT34 → KMP-T34 (mittig trennen für Lesbarkeit)
        return if (code.length >= 4) {
            val mid = code.length / 2
            "${code.substring(0, mid)}-${code.substring(mid)}"
        } else code
    }

    override fun onDestroy() {
        pollJob?.cancel()
        super.onDestroy()
    }
}
