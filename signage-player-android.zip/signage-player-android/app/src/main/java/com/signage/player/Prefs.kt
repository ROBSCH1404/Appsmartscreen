package com.signage.player

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

object Prefs {
    private const val NAME = "signage_prefs"
    private const val KEY_SERVER_URL = "server_url"
    private const val KEY_TOKEN = "token"
    private const val KEY_DEVICE_ID = "device_id"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)
    }

    var serverUrl: String?
        get() = prefs.getString(KEY_SERVER_URL, null)
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value?.trimEnd('/')).apply()

    var token: String?
        get() = prefs.getString(KEY_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_TOKEN, value).apply()

    val deviceId: String
        get() {
            var id = prefs.getString(KEY_DEVICE_ID, null)
            if (id == null) {
                id = "dev_" + UUID.randomUUID().toString().replace("-", "").take(16)
                prefs.edit().putString(KEY_DEVICE_ID, id).apply()
            }
            return id
        }

    fun reset() {
        prefs.edit()
            .remove(KEY_TOKEN)
            .apply()
    }

    fun resetAll() {
        prefs.edit().clear().apply()
    }
}
