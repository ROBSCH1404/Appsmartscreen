package com.signage.player

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Router-Activity: entscheidet beim App-Start, wohin der User geht.
 * - Kein Server konfiguriert → SetupActivity
 * - Server aber kein Token → PairingActivity
 * - Token vorhanden → PlayerActivity
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        route()
        finish()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        route()
        finish()
    }

    private fun route() {
        val next = when {
            Prefs.serverUrl.isNullOrBlank() -> SetupActivity::class.java
            Prefs.token.isNullOrBlank() -> PairingActivity::class.java
            else -> PlayerActivity::class.java
        }
        startActivity(Intent(this, next).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        })
    }
}
