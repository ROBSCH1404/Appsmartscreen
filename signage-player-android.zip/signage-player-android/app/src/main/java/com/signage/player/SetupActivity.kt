package com.signage.player

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.signage.player.databinding.ActivitySetupBinding

class SetupActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySetupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.serverUrlInput.setText(Prefs.serverUrl ?: "http://")
        binding.deviceId.text = getString(R.string.device_id_label, Prefs.deviceId)

        binding.saveButton.setOnClickListener {
            val url = binding.serverUrlInput.text.toString().trim()
            if (!url.matches(Regex("^https?://.+"))) {
                Toast.makeText(this, R.string.invalid_url, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.serverUrl = url
            startActivity(Intent(this, PairingActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            })
            finish()
        }
    }
}
