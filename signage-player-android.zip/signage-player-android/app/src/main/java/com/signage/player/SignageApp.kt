package com.signage.player

import android.app.Application

class SignageApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
