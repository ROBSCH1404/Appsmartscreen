package com.signage.player

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    sealed class Result<out T> {
        data class Success<T>(val data: T) : Result<T>()
        data class Error(val message: String, val code: Int = 0) : Result<Nothing>()
    }

    private fun serverUrl(): String {
        return Prefs.serverUrl ?: throw IllegalStateException("Server-URL nicht gesetzt")
    }

    // POST /api/pairing/generate → { code, expires_at }
    suspend fun requestPairingCode(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().put("device_id", Prefs.deviceId).toString()
                .toRequestBody(JSON)
            val req = Request.Builder()
                .url("${serverUrl()}/api/pairing/generate")
                .post(body)
                .build()
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@withContext Result.Error("HTTP ${res.code}", res.code)
                val json = JSONObject(res.body?.string() ?: "{}")
                Result.Success(json.getString("code"))
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Netzwerkfehler")
        }
    }

    // GET /api/pairing/status?code=&device_id= → { status, token? }
    suspend fun checkPairingStatus(code: String): Result<PairingStatus> = withContext(Dispatchers.IO) {
        try {
            val url = "${serverUrl()}/api/pairing/status?code=$code&device_id=${Prefs.deviceId}"
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { res ->
                if (res.code == 404) return@withContext Result.Success(PairingStatus.Expired)
                if (!res.isSuccessful) return@withContext Result.Error("HTTP ${res.code}", res.code)
                val json = JSONObject(res.body?.string() ?: "{}")
                when (json.optString("status")) {
                    "paired" -> Result.Success(PairingStatus.Paired(json.getString("token")))
                    "expired" -> Result.Success(PairingStatus.Expired)
                    else -> Result.Success(PairingStatus.Pending)
                }
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Netzwerkfehler")
        }
    }

    // GET /api/player/<token>/config → PlayerConfig
    suspend fun fetchPlayerConfig(): Result<PlayerConfig> = withContext(Dispatchers.IO) {
        try {
            val token = Prefs.token ?: return@withContext Result.Error("Kein Token")
            val req = Request.Builder()
                .url("${serverUrl()}/api/player/$token/config")
                .build()
            client.newCall(req).execute().use { res ->
                if (res.code == 404) return@withContext Result.Error("Bildschirm unbekannt", 404)
                if (!res.isSuccessful) return@withContext Result.Error("HTTP ${res.code}", res.code)
                val json = JSONObject(res.body?.string() ?: "{}")
                Result.Success(PlayerConfig.fromJson(json))
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Netzwerkfehler")
        }
    }

    // Vollständige URL für Medium (Token wird gebraucht damit /player-media/ funktioniert)
    fun mediaUrl(relativePath: String): String {
        return "${serverUrl()}$relativePath"
    }
}

sealed class PairingStatus {
    object Pending : PairingStatus()
    object Expired : PairingStatus()
    data class Paired(val token: String) : PairingStatus()
}
