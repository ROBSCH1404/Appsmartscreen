package com.signage.player

import org.json.JSONObject

data class PlayerConfig(
    val screenName: String,
    val playlistName: String?,
    val items: List<PlaylistItem>,
    val pollIntervalSec: Int
) {
    companion object {
        fun fromJson(json: JSONObject): PlayerConfig {
            val screen = json.optJSONObject("screen")
            val playlist = json.optJSONObject("playlist")
            val items = mutableListOf<PlaylistItem>()

            if (playlist != null) {
                val arr = playlist.optJSONArray("items")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val it = arr.getJSONObject(i)
                        items.add(
                            PlaylistItem(
                                id = it.getInt("id"),
                                kind = it.getString("kind"),
                                url = it.getString("url"),
                                durationSec = it.getInt("duration"),
                                name = it.optString("name", "")
                            )
                        )
                    }
                }
            }

            return PlayerConfig(
                screenName = screen?.optString("name", "?") ?: "?",
                playlistName = playlist?.optString("name"),
                items = items,
                pollIntervalSec = json.optInt("poll_interval", 30)
            )
        }
    }

    fun playlistHash(): String {
        return items.joinToString("|") { "${it.id}:${it.durationSec}" }
    }
}

data class PlaylistItem(
    val id: Int,
    val kind: String, // "image" oder "video"
    val url: String,
    val durationSec: Int,
    val name: String
) {
    val isImage: Boolean get() = kind == "image"
    val isVideo: Boolean get() = kind == "video"
}
